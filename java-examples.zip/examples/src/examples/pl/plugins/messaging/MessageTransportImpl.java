package examples.pl.plugins.messaging;

import gw.plugin.messaging.InitializationException;
import entity.Message;
import gw.plugin.messaging.MessageTransport;
import org.osgi.service.component.annotations.Component;

@Component
public class MessageTransportImpl implements MessageTransport {

  @Override
  public void send(Message message, String transformedPayload) throws Exception {
    //LoggerCategory.MESSAGING.info("Received (" + message.getID() + "): " + transformedPayload);
    QueueSimulator.getInstance().put(message);
  }

  @Override
  public void shutdown() {
  }

  @Override
  public void suspend() {
  }

  @Override
  public void resume() throws InitializationException {
  }

  @Override
  public void setDestinationID(int destinationID) {
  }
}
